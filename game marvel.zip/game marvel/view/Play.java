package view;

import engine.Game;
import engine.Player;
import exceptions.*;
import model.abilities.*;
import model.effects.Effect;
import model.world.Champion;
import model.world.Cover;
import model.world.Direction;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.*;

public class Play extends JFrame {
	ImageIcon img= new ImageIcon("cosmic-background-with-colorful-laser-lights-perfect-digital-wallpaper.png");
	JLabel background= new JLabel();
	JPanel mainPanel;
	JButton startButton= new JButton("Start Game");
	JTextArea namefinfo;
	JTextArea names;
	JButton castability4 ;
	public Play() {
		this.setTitle("Marvel Ultimate War");
		this.setVisible(true);
		//this.setIconImage("button.png");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(1400,870);
		this.setLayout(new BorderLayout());
		this.setLocationRelativeTo(null);
		background.setIcon(img);
		//this.setFocusable(true);
		createStartPage();
		//CardLayout card= new CardLayout();
		//card.addLayoutComponent(startPanel,null);
		//this.pack();
        //c.setFocusable(false);
        //x.add(c,BorderLayout.CENTER);
    }
    public void createStartPage(){
		mainPanel = new JPanel();
		mainPanel.setVisible(true);
		mainPanel.setLayout(new BorderLayout());
		mainPanel.add(background);
		startButton.addActionListener(e -> createPanel());
		startButton.setFocusable(false);
		startButton.setBounds(650,780,100,50);
		this.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if(e.getKeyCode()== KeyEvent.VK_ENTER)
					createPanel();
			}
		});
		background.add(startButton);
		//c.setText("Start Game!");
		startButton.setBackground(Color.GREEN);
		startButton.setOpaque(true);
		startButton.setHorizontalTextPosition(JLabel.CENTER);
		startButton.setVerticalTextPosition( JLabel.CENTER);
		background.setHorizontalAlignment(JLabel.CENTER);
		background.setVerticalAlignment(JLabel.CENTER);
		this.add(mainPanel,BorderLayout.CENTER);
		this.revalidate();
		this.repaint();
	}
   public void createPanel(){
		background.remove(startButton);
	   // name for first player
	   JLabel firstP = new JLabel("First player");
	   firstP.setBounds(200, 200, 100, 60);
	   background.add(firstP);
	   JTextField first= new JTextField("Enter name of first player");// larger font and make it bold
	   first.setFont(new Font("Consolas", Font.ITALIC, 12));
	   first.requestFocus();
	   first.addMouseListener(new MouseListener() {

		   public void mouseClicked(MouseEvent e) {
			   if (e.getSource().equals(first)){
			   	first.setFont(new Font("Consolas", Font.PLAIN, 12));
			   	first.setText("");
			   }
		   }

		   public void mousePressed(MouseEvent e) {

		   }


		   public void mouseReleased(MouseEvent e) {

		   }

		   public void mouseEntered(MouseEvent e) {

		   }

		   public void mouseExited(MouseEvent e) {

		   }
	   });
	   first.setBounds(350,200,250, 50);
	   background.add(first);
	   //name for next player
	   JLabel secondP = new JLabel("Second player");
	   secondP.setBounds(200, 250, 100, 60);
	   background.add(secondP);
	   JTextField second= new JTextField("Enter name of second player");
	   second.setFont(new Font("Consolas", Font.ITALIC, 12));
	   second.requestFocus();
	   second.addMouseListener(new MouseListener() {

		   public void mouseClicked(MouseEvent e) {
			   if (e.getSource().equals(second)){
			   	second.setFont(new Font("Consolas", Font.PLAIN, 12));
			   second.setText("");
			   }
		   }

		   public void mousePressed(MouseEvent e) {

		   }


		   public void mouseReleased(MouseEvent e) {

		   }

		   public void mouseEntered(MouseEvent e) {

		   }

		   public void mouseExited(MouseEvent e) {

		   }
	   });
	   second.addKeyListener(new KeyAdapter() {
	   	public void keyReleased(KeyEvent e) {
			   if(e.getKeyCode()== KeyEvent.VK_ENTER){
				   if (first.getText().equals(""))
					   JOptionPane.showMessageDialog(null,"Name of first player cannot be empty","First Player name not Entered", JOptionPane.ERROR_MESSAGE);
				   else	if (second.getText().equals(""))
					   JOptionPane.showMessageDialog(null,"Name of second player cannot be empty","Second Player name not Entered", JOptionPane.ERROR_MESSAGE);
				   else{
					   try {
						   chooseYourFighter(first.getText(),second.getText());
					   } catch (IOException ioException) {
						   ioException.printStackTrace();
					   }}
			   }
		   }
	   });
	   second.setBounds(350,250,250, 50);
	   background.add(second);
	   JButton enter = new JButton("Enter");
	   enter.addActionListener(e -> {
	   	if (first.getText().equals(""))
	   		JOptionPane.showMessageDialog(null,"Name of first player cannot be empty","First Player name not Entered", JOptionPane.ERROR_MESSAGE);
	   else	if (second.getText().equals(""))
			   JOptionPane.showMessageDialog(null,"Name of second player cannot be empty","Second Player name not Entered", JOptionPane.ERROR_MESSAGE);
		 else{
		   try {
			   chooseYourFighter(first.getText(),second.getText());
		   } catch (IOException ioException) {
			   ioException.printStackTrace();
		   }}
	   });
	   this.addKeyListener(new KeyAdapter() {
		   @Override
		   public void keyReleased(KeyEvent e) {
			   if(e.getKeyCode()== KeyEvent.VK_ENTER){
				   if (first.getText().equals(""))
					   JOptionPane.showMessageDialog(null,"Name of first player cannot be empty","First Player name not Entered", JOptionPane.ERROR_MESSAGE);
				   else	if (second.getText().equals(""))
					   JOptionPane.showMessageDialog(null,"Name of second player cannot be empty","Second Player name not Entered", JOptionPane.ERROR_MESSAGE);
				   else{
					   try {
						   chooseYourFighter(first.getText(),second.getText());
					   } catch (IOException ioException) {
						   ioException.printStackTrace();
					   }}
			   }
		   }
	   });
	  // enter.addKeyListener();
	   enter.setFocusable(false);
	   enter.setBounds(200, 300, 60, 20);
	   background.add(enter);
	   //mainPanel.add(background);
	   //frame.add(panel);
	   this.revalidate();
	   this.repaint();
   }
	public void chooseYourFighter(String firstPlayer, String secondPlayer) throws IOException {
		mainPanel.removeAll();
		mainPanel.setBackground(Color.blue);
		mainPanel.setLayout(new GridLayout(5,5));
		mainPanel.setBounds(350, 400, 600, 500);
		JTextArea left = new JTextArea();
		this.add(left,BorderLayout.EAST);
		left.setEditable(false);
		String stext="         "+secondPlayer+"             ";
		left.setText(stext);
		left.setPreferredSize(new Dimension(300,getHeight()));

		JTextArea right = new JTextArea();
		this.add(right,BorderLayout.WEST);
		right.setEditable(false);
		String ftext="        "+firstPlayer+"              ";
		right.setText(ftext);
		right.setPreferredSize(new Dimension(300,getHeight()));

		mainPanel.setLayout(new GridLayout(0,3));

		Player first= new Player(firstPlayer);
		Player second=new Player(secondPlayer);
		Game g=new Game(first,second);
		g.loadAbilities("Abilities.csv");
		g.loadChampions("Champions.csv");

		JFrame champinfo= new JFrame();
		champinfo.setLocation(10,400);
		champinfo.setSize(300,300);
		JTextArea champp= new JTextArea();

		champp.setPreferredSize(new Dimension(500,500));
		champp.setFont(new Font(Font.SERIF, Font.PLAIN,20));
		champinfo.add(champp);

		JButton x1 = new JButton(g.getAvailableChampions().get(0).getName());
		x1.setIcon(new ImageIcon("Captain America.png"));
		x1.setVerticalTextPosition(SwingConstants.TOP);
		x1.setHorizontalTextPosition(SwingConstants.CENTER);
		x1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x1) {
					champinfo.setTitle(g.getAvailableChampions().get(0).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(0).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(0).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(0).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(0).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(0).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(0).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(0).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(0).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x1)
					champinfo.dispose();
			}
		});

		JButton x2= new JButton(g.getAvailableChampions().get(1).getName());
		x2.setIcon(new ImageIcon("Deadpool.png"));
		x2.setIconTextGap(-4);
		x2.setVerticalTextPosition(SwingConstants.TOP);
		x2.setHorizontalTextPosition(SwingConstants.CENTER);
		x2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x2){
					champinfo.setTitle(g.getAvailableChampions().get(1).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(1).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(1).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(1).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(1).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(1).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(1).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(1).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(1).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x2)
					champinfo.dispose();
			}
		});

		JButton x3= new JButton(g.getAvailableChampions().get(2).getName());
		x3.setIcon(new ImageIcon("Dr Strange.png"));
		x3.setVerticalTextPosition(SwingConstants.TOP);
		x3.setHorizontalTextPosition(SwingConstants.CENTER);
		x3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x3){
					champinfo.setTitle(g.getAvailableChampions().get(2).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(2).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(2).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(2).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(2).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(2).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(2).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(2).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(2).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x3)
					champinfo.dispose();
			}
		});

		JButton x4= new JButton(g.getAvailableChampions().get(3).getName());
		x4.setIcon(new ImageIcon("Electro.png"));
		x4.setIconTextGap(-15);
		x4.setVerticalTextPosition(SwingConstants.TOP);
		x4.setHorizontalTextPosition(SwingConstants.CENTER);
		x4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x4){
					champinfo.setTitle(g.getAvailableChampions().get(3).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(3).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(3).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(3).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(3).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(3).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(3).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(3).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(3).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x4)
					champinfo.dispose();
			}
		});

		JButton x5= new JButton(g.getAvailableChampions().get(4).getName());
		x5.setIcon(new ImageIcon("Ghost Rider.png"));
		x5.setVerticalTextPosition(SwingConstants.TOP);
		x5.setHorizontalTextPosition(SwingConstants.CENTER);
		x5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x5){
					champinfo.setTitle(g.getAvailableChampions().get(4).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(4).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(4).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(4).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(4).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(4).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(4).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(4).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(4).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x5)
					champinfo.dispose();
			}
		});

		JButton x6= new JButton(g.getAvailableChampions().get(5).getName());
		x6.setIcon(new ImageIcon("Hela.png"));
		x6.setVerticalTextPosition(SwingConstants.TOP);
		x6.setHorizontalTextPosition(SwingConstants.CENTER);
		x6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x6){
					champinfo.setTitle(g.getAvailableChampions().get(5).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(5).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(5).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(5).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(5).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(5).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(5).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(5).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(5).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x6)
					champinfo.dispose();
			}
		});

		JButton x7= new JButton(g.getAvailableChampions().get(6).getName());
		x7.setIcon(new ImageIcon("Hulk.png"));
		x7.setVerticalTextPosition(SwingConstants.TOP);
		x7.setHorizontalTextPosition(SwingConstants.CENTER);
		x7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x7){
					champinfo.setTitle(g.getAvailableChampions().get(6).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(6).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(6).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(6).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(6).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(6).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(6).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(6).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(6).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x7)
					champinfo.dispose();
			}
		});

		JButton x8= new JButton(g.getAvailableChampions().get(7).getName());
		x8.setIcon(new ImageIcon("Iceman.png"));
		x8.setVerticalTextPosition(SwingConstants.TOP);
		x8.setHorizontalTextPosition(SwingConstants.CENTER);
		x8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x8){
					champinfo.setTitle(g.getAvailableChampions().get(7).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(7).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(7).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(7).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(7).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(7).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(7).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(7).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(7).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x8)
					champinfo.dispose();
			}
		});

		JButton x9= new JButton(g.getAvailableChampions().get(8).getName());
		x9.setIcon(new ImageIcon("Ironman.png"));
		x9.setVerticalTextPosition(SwingConstants.TOP);
		x9.setHorizontalTextPosition(SwingConstants.CENTER);
		x9.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x9){
					champinfo.setTitle(g.getAvailableChampions().get(8).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(8).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(8).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(8).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(8).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(8).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(8).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(8).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(8).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x9)
					champinfo.dispose();
			}
		});

		JButton x10= new JButton(g.getAvailableChampions().get(9).getName());
		x10.setIcon(new ImageIcon("Loki.png"));
		x10.setVerticalTextPosition(SwingConstants.TOP);
		x10.setHorizontalTextPosition(SwingConstants.CENTER);
		x10.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x10){
					champinfo.setTitle(g.getAvailableChampions().get(9).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(9).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(9).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(9).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(9).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(9).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(9).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(9).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(9).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x10)
					champinfo.dispose();
			}
		});

		JButton x11= new JButton(g.getAvailableChampions().get(10).getName());
		x11.setIcon(new ImageIcon("Quicksilver.png"));
		x11.setVerticalTextPosition(SwingConstants.TOP);
		x11.setHorizontalTextPosition(SwingConstants.CENTER);
		x11.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x11){
					champinfo.setTitle(g.getAvailableChampions().get(10).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(10).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(10).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(10).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(10).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(10).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(10).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(10).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(10).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x11)
					champinfo.dispose();
			}
		});

		JButton x12= new JButton(g.getAvailableChampions().get(11).getName());
		x12.setIcon(new ImageIcon("Spiderman.png"));
		//x12.setIconTextGap();
		x12.setVerticalTextPosition(SwingConstants.TOP);
		x12.setHorizontalTextPosition(SwingConstants.CENTER);
		x12.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x12){
					champinfo.setTitle(g.getAvailableChampions().get(11).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(11).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(11).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(11).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(11).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(11).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(11).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(11).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(11).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x12)
					champinfo.dispose();
			}
		});

		JButton x13= new JButton(g.getAvailableChampions().get(12).getName());
		x13.setIcon(new ImageIcon("Thor.png"));
		x13.setIconTextGap(-22);
		x13.setVerticalTextPosition(SwingConstants.TOP);
		x13.setHorizontalTextPosition(SwingConstants.CENTER);
		x13.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x13){
					champinfo.setTitle(g.getAvailableChampions().get(12).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(12).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(12).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(12).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(12).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(12).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(12).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(12).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(12).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x13)
					champinfo.dispose();
			}
		});

		JButton x14= new JButton(g.getAvailableChampions().get(13).getName());
		x14.setIcon(new ImageIcon("Venom.png"));
		x14.setIconTextGap(-9);
		x14.setVerticalTextPosition(SwingConstants.TOP);
		x14.setHorizontalTextPosition(SwingConstants.CENTER);
		x14.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x14){
					champinfo.setTitle(g.getAvailableChampions().get(13).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(13).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(13).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(13).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(13).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(13).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(13).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(13).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(13).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x14)
					champinfo.dispose();
			}
		});

		JButton x15= new JButton(g.getAvailableChampions().get(14).getName());
		x15.setIcon(new ImageIcon("Yellow Jacket.png"));
		x15.setIconTextGap(-4);
		x15.setVerticalTextPosition(SwingConstants.TOP);
		x15.setHorizontalTextPosition(SwingConstants.CENTER);
		x15.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				if (e.getSource()==x15){
					champinfo.setTitle(g.getAvailableChampions().get(14).getName()+" information");
					champp.setText(" Name: "+g.getAvailableChampions().get(14).getName()+ "\n"+
							"Type: "+g.getAvailableChampions().get(14).getClass().getSimpleName()+"\n"+
							" HP: "+g.getAvailableChampions().get(14).getCurrentHP()+"\n"+
							" Attack Damage: "+g.getAvailableChampions().get(14).getAttackDamage()+"\n"+
							" Speed: "+g.getAvailableChampions().get(14).getSpeed()+"\n"+
							" Mana: "+g.getAvailableChampions().get(14).getMana()+"\n"
							+" Abilities:" +"\n");

					for(int i=0;i<g.getAvailableChampions().get(14).getAbilities().size();i++)
						champp.setText(champp.getText()+" "+g.getAvailableChampions().get(14).getAbilities().get(i).getName() + "\n" );
					champinfo.setVisible(true);
				}
			}

			public void mouseExited(MouseEvent e) {
				if (e.getSource()==x15)
					champinfo.dispose();
			}
		});

		mainPanel.add(x1);
		mainPanel.add(x2);
		mainPanel.add(x3);
		mainPanel.add(x4);
		mainPanel.add(x5);
		mainPanel.add(x6);
		mainPanel.add(x7);
		mainPanel.add(x8);
		mainPanel.add(x9);
		mainPanel.add(x10);
		mainPanel.add(x11);
		mainPanel.add(x12);
		mainPanel.add(x13);
		mainPanel.add(x14);
		mainPanel.add(x15);
		
		x1.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(0));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(0).getName());
			}
			else{
				if (second.getTeam().size()<3){
				second.getTeam().add(Game.getAvailableChampions().get(0));
				left.setText(left.getText()+"\n "+Game.getAvailableChampions().get(0).getName());
				}
				if (second.getTeam().size()==3){
					champinfo.dispose();
					this.remove(right);
					this.remove(left);
					chooseLeader(first,second,g);
				}
			}
			x1.setEnabled(false);
		});
		x2.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(1));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(1).getName());
			}
			else{
				if (second.getTeam().size()<3){
					second.getTeam().add(Game.getAvailableChampions().get(1));
					left.setText(left.getText()+"\n " +Game.getAvailableChampions().get(1).getName());
				}
				if (second.getTeam().size()==3){
					champinfo.dispose();
					this.remove(right);
					this.remove(left);
					chooseLeader(first,second,g);
				}
			}
			x2.setEnabled(false);
		});
		x3.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(2));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(2).getName());
			}
			else{
				if (second.getTeam().size()<3){
					second.getTeam().add(Game.getAvailableChampions().get(2));
					left.setText(left.getText()+"\n " +Game.getAvailableChampions().get(2).getName());
				}
				if (second.getTeam().size()==3){
					champinfo.dispose();
					this.remove(right);
					this.remove(left);
					chooseLeader(first,second,g);
				}
			}
			x3.setEnabled(false);
		});
		x4.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(3));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(3).getName());
			}
			else{
				if (second.getTeam().size()<3){
					second.getTeam().add(Game.getAvailableChampions().get(3));
					left.setText(left.getText()+"\n " +Game.getAvailableChampions().get(3).getName());
				}
				if (second.getTeam().size()==3){
					champinfo.dispose();
					this.remove(right);
					this.remove(left);
					chooseLeader(first, second,g);
				}
			}
			x4.setEnabled(false);
		});
		x5.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(4));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(4).getName());
			}
			else{
				if (second.getTeam().size()<3){
					second.getTeam().add(Game.getAvailableChampions().get(4));
					left.setText(left.getText()+"\n " +Game.getAvailableChampions().get(4).getName());
				}
				if (second.getTeam().size()==3){
					champinfo.dispose();
					this.remove(right);
					this.remove(left);
					chooseLeader(first,second,g);
				}
			}
			x5.setEnabled(false);
		});
		x6.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(5));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(5).getName());
			}
			else{
				if (second.getTeam().size()<3){
					second.getTeam().add(Game.getAvailableChampions().get(5));
					left.setText(left.getText()+"\n " +Game.getAvailableChampions().get(5).getName());
				}
				if (second.getTeam().size()==3){
					champinfo.dispose();
					this.remove(right);
					this.remove(left);
					chooseLeader(first,second,g);
				}
			}
			x6.setEnabled(false);
		});
		x7.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(6));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(6).getName());
			}
			else{
				if (second.getTeam().size()<3){
					second.getTeam().add(Game.getAvailableChampions().get(6));
					left.setText(left.getText()+"\n " +Game.getAvailableChampions().get(6).getName());
				}
				if (second.getTeam().size()==3){
					champinfo.dispose();
					this.remove(right);
					this.remove(left);
					chooseLeader(first,second,g);
				}
			}
			x7.setEnabled(false);
		});
		x8.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(7));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(7).getName());
			}
			else{
				if (second.getTeam().size()<3) {
					second.getTeam().add(Game.getAvailableChampions().get(7));
					left.setText(left.getText()+"\n " +Game.getAvailableChampions().get(7).getName());
				}
				if (second.getTeam().size()==3){
					champinfo.dispose();
					this.remove(right);
					this.remove(left);
					chooseLeader(first,second,g);
				}
			}
			x8.setEnabled(false);
		});
		x9.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(8));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(8).getName());
			}
			else{
				if (second.getTeam().size()<3){
					second.getTeam().add(Game.getAvailableChampions().get(8));
					left.setText(left.getText()+"\n " +Game.getAvailableChampions().get(8).getName());
				}
				if (second.getTeam().size()==3){
					champinfo.dispose();
					this.remove(right);
					this.remove(left);
					chooseLeader(first,second,g);
				}
			}
			x9.setEnabled(false);
		});
		x10.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(9));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(9).getName());
			}
			else{
				if (second.getTeam().size()<3){
					second.getTeam().add(Game.getAvailableChampions().get(9));
					left.setText(left.getText()+"\n " +Game.getAvailableChampions().get(9).getName());
				}

				if (second.getTeam().size()==3){
					champinfo.dispose();
					this.remove(right);
					this.remove(left);
					chooseLeader(first,second,g);
				}
			}
			x10.setEnabled(false);
		});
		x11.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(10));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(10).getName());
			}
			else{
				if (second.getTeam().size()<3){
					second.getTeam().add(Game.getAvailableChampions().get(10));
					left.setText(left.getText()+"\n " +Game.getAvailableChampions().get(10).getName());
				}
				if (second.getTeam().size()==3){
					champinfo.dispose();
					this.remove(right);
					this.remove(left);
					chooseLeader(first,second,g);
				}
			}
			x11.setEnabled(false);
		});
		x12.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(11));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(11).getName());
			}
			else{
				if (second.getTeam().size()<3){
					second.getTeam().add(Game.getAvailableChampions().get(11));
					left.setText(left.getText()+"\n " +Game.getAvailableChampions().get(11).getName());
				}
				if (second.getTeam().size()==3){
					champinfo.dispose();
					this.remove(right);
					this.remove(left);
					chooseLeader(first,second,g);
				}
			}
			x12.setEnabled(false);
		});
		x13.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(12));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(12).getName());
			}
			else{
				if (second.getTeam().size()<3){
					second.getTeam().add(Game.getAvailableChampions().get(12));
					left.setText(left.getText()+"\n " +Game.getAvailableChampions().get(12).getName());
				}
				if (second.getTeam().size()==3){
					champinfo.dispose();
					this.remove(right);
					this.remove(left);
					chooseLeader(first,second,g);
				}
			}
			x13.setEnabled(false);
		});
		x14.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(13));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(13).getName());
			}
			else{
				if (second.getTeam().size()<3){
					second.getTeam().add(Game.getAvailableChampions().get(13));
					left.setText(left.getText()+"\n " +Game.getAvailableChampions().get(13).getName());
				}
				if (second.getTeam().size()==3){
					champinfo.dispose();
					this.remove(right);
					this.remove(left);
					chooseLeader(first,second,g);
				}
			}
			x14.setEnabled(false);
		});
		x15.addActionListener(e -> {
			if (first.getTeam().size()<3){
				first.getTeam().add(Game.getAvailableChampions().get(14));
				right.setText(right.getText()+"\n " +Game.getAvailableChampions().get(14).getName());
			}
			else{
				if (second.getTeam().size()<3){
					second.getTeam().add(Game.getAvailableChampions().get(14));
					left.setText(left.getText()+"\n " +Game.getAvailableChampions().get(14).getName());
				}
				if (second.getTeam().size()==3){
					this.remove(right);
					this.remove(left);
					champinfo.dispose();
					chooseLeader(first,second,g);
				}
			}
			x15.setEnabled(false);
		});
		this.revalidate();
		this.repaint();


	}
	public void chooseLeader(Player firstP, Player secondP, Game g){
		background.removeAll();
		mainPanel.removeAll();
		background.setIcon(new ImageIcon("pngwing.com.png"));
		background.setHorizontalAlignment(SwingConstants.TRAILING);
		background.setIconTextGap(40);
		mainPanel.add(background);
		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBounds(0,0,1400,this.getHeight());
		mainPanel.setMinimumSize(new Dimension(getWidth(),getHeight()));
		mainPanel.setBackground(Color.gray);

		this.setLayout(new BorderLayout());

		JLabel first= new JLabel();
		first.setText( firstP.getName() + "! Please choose your Leader ");
		first.setVerticalTextPosition(JLabel.TOP);
		first.setVerticalAlignment(JLabel.TOP);
		first.setBounds(0,0,700,1000);
		first.setFont(new Font(Font.SERIF,Font.BOLD,20));
		first.setBackground(Color.lightGray);
		JRadioButton fchamp1= new JRadioButton(firstP.getTeam().get(0).getName());
		fchamp1.addActionListener(e-> firstP.setLeader(firstP.getTeam().get(0)));
		JRadioButton fchamp2= new JRadioButton(firstP.getTeam().get(1).getName());
		fchamp2.addActionListener(e->firstP.setLeader(firstP.getTeam().get(1)));
		JRadioButton fchamp3= new JRadioButton(firstP.getTeam().get(2).getName());
		fchamp3.addActionListener(e->firstP.setLeader(firstP.getTeam().get(2)));
		fchamp1.setBounds(0, 100, 350, 100);
		fchamp2.setBounds(0, 250, 350,100);
		fchamp3.setBounds(0,350, 350,100);
		ButtonGroup fgroup= new ButtonGroup();
		fgroup.add(fchamp1);
		fgroup.add(fchamp2);
		fgroup.add(fchamp3);
		background.add(fchamp1);
		background.add(fchamp2);
		background.add(fchamp3);
		background.add(first);
		JButton play=new JButton("Next");
		play.addActionListener(e-> {
			if (fgroup.getSelection()==null)
				JOptionPane.showMessageDialog(null,"You Have To select a Leader","No Leader Selected",JOptionPane.ERROR_MESSAGE);
			else
				chooseLeader2(firstP,secondP,g);
		});

		play.setBounds(450,700, 200,50);
		background.add(play);
		//mainPanel.add(b);
		this.add(mainPanel);
		//this.pack();
		this.repaint();
		this.revalidate();
	}
	public void chooseLeader2(Player firstP, Player secondP, Game g){
		background.removeAll();
		background.setIcon(new ImageIcon("pngwing.com.png"));
		background.setHorizontalAlignment(SwingConstants.TRAILING);
		background.setIconTextGap(40);
		JLabel second=new JLabel();
		second.setText(" "+secondP.getName() + "! Please choose your Leader ");
		second.setVerticalTextPosition(JLabel.TOP);
		second.setVerticalAlignment(JLabel.TOP);
		second.setFont(new Font(Font.SERIF,Font.BOLD,20));
		second.setBackground(Color.lightGray);
		second.setBounds(0,0,700,1000);
		JRadioButton schamp1= new JRadioButton(secondP.getTeam().get(0).getName());
		schamp1.addActionListener(e->secondP.setLeader(secondP.getTeam().get(0)));
		JRadioButton schamp2= new JRadioButton(secondP.getTeam().get(1).getName());
		schamp2.addActionListener(e-> secondP.setLeader(secondP.getTeam().get(1)));
		JRadioButton schamp3= new JRadioButton(secondP.getTeam().get(2).getName());
		schamp3.addActionListener(e->secondP.setLeader(secondP.getTeam().get(2)));
		schamp1.setBounds(0, 100, 350, 100);
		schamp2.setBounds(0, 250, 350,100);
		schamp3.setBounds(0,350, 350,100);
		ButtonGroup sgroup=new ButtonGroup();
		sgroup.add(schamp1);
		sgroup.add(schamp2);
		sgroup.add(schamp3);
		background.add(schamp1);
		background.add(schamp2);
		background.add(schamp3);
		background.add(second);
		JButton play=new JButton("Play");
		play.addActionListener(e-> {
			try {
				if (sgroup.getSelection()==null)
					JOptionPane.showMessageDialog(null,"You Have To select a Leader","No Leader Selected",JOptionPane.ERROR_MESSAGE);
				else
				gameBoard(secondP,firstP,g);
			} catch (UnallowedMovementException unallowedMovementException) {
				unallowedMovementException.printStackTrace();
			} catch (NotEnoughResourcesException notEnoughResourcesException) {
				notEnoughResourcesException.printStackTrace();
			} catch (AbilityUseException e1) {
				e1.printStackTrace();
			}
		});

		play.setBounds(450,700, 200,50);
		background.add(play);
		this.repaint();
		this.revalidate();

	}

	public void addabi(Game g,JPanel left,JPanel right) {
		JPanel abi2 = new JPanel();
		String ss []= {g.getCurrentChampion().getAbilities().get(0).getName(),g.getCurrentChampion().getAbilities().get(1).getName(),g.getCurrentChampion().getAbilities().get(2).getName()}; 
		final JComboBox abi22 = new JComboBox(ss);
		abi2.setOpaque(true);
		abi2.add(abi22);
		left.add(abi2,BorderLayout.SOUTH);
		JPanel abi1 = new JPanel();
		final JComboBox abi11 = new JComboBox(ss);
		abi1.setOpaque(true);
		abi1.add(abi11);
		right.add(abi1);
		
	}
	public void gameBoard(Player second,Player first, Game g) throws UnallowedMovementException, NotEnoughResourcesException, AbilityUseException {
		mainPanel.removeAll();
		mainPanel.setBackground(Color.black);
		mainPanel.setLayout(new BorderLayout());
		mainPanel.setSize(1400,850);
		JPanel board = new JPanel();
		board.setLayout(new GridLayout(5,5));
		board.setBounds(300,0,700,500);
		ArrayList<JButton> labels = new ArrayList<>();
		boolean flag=false;
		for(int i=0;i<25;i++) {
			JButton label = new JButton();
			label.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
			if(flag) {
				label.setBackground(new Color(253,176,23));
				flag=false;}
			else {
				label.setBackground(new Color(11,39,152));
				flag=true;
			}
			label.setOpaque(true);
			labels.add(label);
			board.add(label);
		}

		mainPanel.add(board,BorderLayout.CENTER);
		g.placeChampions();
		g.prepareChampionTurns();
		JPanel left = new JPanel();
		left.setPreferredSize(new Dimension(250,this.getHeight()));
		mainPanel.add(left,BorderLayout.WEST);
		namefinfo=new JTextArea();
		namefinfo.setEditable(false);
		namefinfo.setText(" "+first.getName()+"\n"+"\n"+ " Leader: "+first.getLeader().getName()+"\n"+"\n"+
				" Leader Ability Used: "+ g.isFirstLeaderAbilityUsed() + "\n"+"\n"+"Team Members:");
		for (Champion c: first.getTeam()){
			namefinfo.setText(namefinfo.getText()+ "\n"+ c.getName() );
		}
		if (first.getTeam().contains(g.getCurrentChampion())) {
			namefinfo.setText(namefinfo.getText() + "\n" + "\n" +
					"Current Champion: " + g.getCurrentChampion().getName() + "\n" +
					" Type: " + g.getCurrentChampion().getClass().getSimpleName() + "\n" +
					" Current HP: " + g.getCurrentChampion().getCurrentHP() + "\n" +
					" Mana: " + g.getCurrentChampion().getMana() + "\n" +
					" Current Action Points: " + g.getCurrentChampion().getCurrentActionPoints() + "\n" + "\n" +
					" Abilities:");

			for (Ability a : g.getCurrentChampion().getAbilities()) {
				if (a instanceof DamagingAbility)
					namefinfo.setText(namefinfo.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
							+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
							"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
							"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
							"  Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+"\n");
				else if (a instanceof HealingAbility)
					namefinfo.setText(namefinfo.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
							+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
							"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
							"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
							"  Healing Amount: " + ((HealingAbility) a).getHealAmount()+"\n");
				else if (a instanceof CrowdControlAbility)
					namefinfo.setText(namefinfo.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
							+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
							"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
							"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
							"  Effect: " + ((CrowdControlAbility) a).getEffect().getName()+"\n");
			}
			/*if (g.getCurrentChampion().getAppliedEffects().size()>0){
				namefinfo.setText(namefinfo.getText()+"\n"+" Applied Effects: ");
			for (Effect e:g.getCurrentChampion().getAppliedEffects()){
				namefinfo.setText(namefinfo.getText()+"\n"+"  "+e.getName()+", Duration: "+e.getDuration());
			}}*/
		}
		namefinfo.setPreferredSize(new Dimension(220,getHeight()));
		//namef.add(namefinfo);
		left.add(namefinfo);
		

		JPanel right = new JPanel();
		right.setPreferredSize(new Dimension(250,this.getHeight()));
		mainPanel.add(right,BorderLayout.EAST);
		names = new JTextArea();
		names.setEditable(false);
		names.setText(second.getName()+"\n"+"\n"+ "Leader: "+second.getLeader().getName()+"\n"+"\n"+
				"Leader Ability Used: "+ g.isSecondLeaderAbilityUsed()+ "\n"+"\n"+"Team Members:");

		for (Champion c: second.getTeam())
			names.setText(names.getText()+ "\n"+ c.getName() );

		if (second.getTeam().contains(g.getCurrentChampion())){
			names.setText(names.getText()+ "\n"+"\n"+
					"Current Champion: "+ g.getCurrentChampion().getName()+"\n"+
					" Type: "+g.getCurrentChampion().getClass().getSimpleName()+"\n"+
					" Current HP: "+ g.getCurrentChampion().getCurrentHP()+ "\n"+
					" Mana: "+ g.getCurrentChampion().getMana() + "\n"+
					" Current Action Points: "+ g.getCurrentChampion().getCurrentActionPoints()+"\n"+"\n"+
					" Abilities:");
			for (Ability a: g.getCurrentChampion().getAbilities()){
				if (a instanceof DamagingAbility)
					names.setText(names.getText()+"\n" +a.getName()+"\n"+ "  Type: "+a.getClass().getSimpleName()+"\n"
					+ "  Area of Effect: "+ a.getCastArea().name() + "\n"+ "  Cast Range: "+ a.getCastRange()+ " cells"+ "\n"+
					"  Mana Cost: "+a.getManaCost()+"\n"+ "  Required Action Points: "+ a.getRequiredActionPoints() +"\n"+
					"  Base Cooldown: "+a.getBaseCooldown() +"\n"+ "  Current Cooldown: "+ a.getCurrentCooldown()+ "\n"+
					"  Damage Amount: "+ ((DamagingAbility) a).getDamageAmount()+"\n");
				else if (a instanceof HealingAbility)
					names.setText(names.getText()+"\n" +a.getName()+"\n"+ "  Type: "+a.getClass().getSimpleName()+"\n"
									+ "  Area of Effect: "+ a.getCastArea().name() + "\n"+ "  Cast Range: "+ a.getCastRange()+ " cells"+ "\n"+
									"  Mana Cost: "+a.getManaCost()+"\n"+ "  Required Action Points: "+ a.getRequiredActionPoints() +"\n"+
									"  Base Cooldown: "+a.getBaseCooldown() +"\n"+ "  Current Cooldown: "+ a.getCurrentCooldown()+ "\n"+
							"  Healing Amount: "+ ((HealingAbility) a).getHealAmount()+"\n");
				else if (a instanceof CrowdControlAbility)
					names.setText(names.getText()+"\n" +a.getName()+"\n"+ "  Type: "+a.getClass().getSimpleName()+"\n"
							+ "  Area of Effect: "+ a.getCastArea().name() + "\n"+ "  Cast Range: "+ a.getCastRange()+ " cells"+ "\n"+
							"  Mana Cost: "+a.getManaCost()+"\n"+ "  Required Action Points: "+ a.getRequiredActionPoints() +"\n"+
							"  Base Cooldown: "+a.getBaseCooldown() +"\n"+ "  Current Cooldown: "+ a.getCurrentCooldown()+ "\n"+
							"  Effect: "+ ((CrowdControlAbility) a).getEffect().getName()+"\n");
			}
			/*if (g.getCurrentChampion().getAppliedEffects().size()>0){
				names.setText(names.getText()+"\n"+" Applied Effects: ");
				for (Effect e:g.getCurrentChampion().getAppliedEffects()){
					names.setText(names.getText()+"\n"+"  "+e.getName()+", Duration: "+e.getDuration());
				}
			}*/
		}
		right.add(names);


		JPanel bottomframe= new JPanel();
		bottomframe.setLayout(new GridLayout(2,8));
		JButton moveu=new JButton("UP");
		moveu.addActionListener(e-> {
			try {
				Point p = g.getCurrentChampion().getLocation();
				g.move(Direction.UP);
				PlaceOnChampGrid(g,labels,p);
			} catch (NotEnoughResourcesException notEnoughResourcesException) {
				JOptionPane.showMessageDialog(null,notEnoughResourcesException.getMessage(),"Not Enough Resources",JOptionPane.ERROR_MESSAGE );
				notEnoughResourcesException.printStackTrace();
			} catch (UnallowedMovementException unallowedMovementException) {
				JOptionPane.showMessageDialog(null,unallowedMovementException.getMessage(),"Unallowed Movement",JOptionPane.ERROR_MESSAGE );
				unallowedMovementException.printStackTrace();
			}
		});
		bottomframe.add(moveu);

		JButton moved=new JButton("DOWN");
		moved.addActionListener(e-> {
			try {
				Point p = g.getCurrentChampion().getLocation();
				g.move(Direction.DOWN);
				PlaceOnChampGrid(g,labels,p);
			} catch (NotEnoughResourcesException notEnoughResourcesException) {
				JOptionPane.showMessageDialog(null,notEnoughResourcesException.getMessage(),"Not Enough Resources",JOptionPane.ERROR_MESSAGE );
				notEnoughResourcesException.printStackTrace();
			} catch (UnallowedMovementException unallowedMovementException) {
				JOptionPane.showMessageDialog(null,unallowedMovementException.getMessage(),"Unallowed Movement",JOptionPane.ERROR_MESSAGE );
				unallowedMovementException.printStackTrace();
			}
		});
		bottomframe.add(moved);

		JButton movel=new JButton("LEFT");
		movel.addActionListener(e-> {
			try {
				Point p = g.getCurrentChampion().getLocation();
				g.move(Direction.LEFT);
				PlaceOnChampGrid(g,labels,p);
			} catch (NotEnoughResourcesException notEnoughResourcesException) {
				JOptionPane.showMessageDialog(null,notEnoughResourcesException.getMessage(),"Not Enough Resources",JOptionPane.ERROR_MESSAGE );
				notEnoughResourcesException.printStackTrace();
			} catch (UnallowedMovementException unallowedMovementException) {
				JOptionPane.showMessageDialog(null,unallowedMovementException.getMessage(),"Unallowed Movement",JOptionPane.ERROR_MESSAGE );
				unallowedMovementException.printStackTrace();
			}
		});
		bottomframe.add(movel);

		JButton mover=new JButton("RIGHT");
		mover.addActionListener(e-> {
			try {
				Point p = g.getCurrentChampion().getLocation();
				g.move(Direction.RIGHT);
				PlaceOnChampGrid(g,labels,p);
			} catch (NotEnoughResourcesException notEnoughResourcesException) {
				JOptionPane.showMessageDialog(null,notEnoughResourcesException.getMessage(),"Not Enough Resources",JOptionPane.ERROR_MESSAGE );
				notEnoughResourcesException.printStackTrace();
			} catch (UnallowedMovementException unallowedMovementException) {
				JOptionPane.showMessageDialog(null,unallowedMovementException.getMessage(),"Unallowed Movement",JOptionPane.ERROR_MESSAGE );
				unallowedMovementException.printStackTrace();
			}
		});
		bottomframe.add(mover);

		JButton attackUp=new JButton("Attack UP");
		attackUp.addActionListener(e-> {
			try {
				g.attack(Direction.UP);
				UpdateForAttack(g,labels);
			} catch (NotEnoughResourcesException notEnoughResourcesException) {
				JOptionPane.showMessageDialog(null,notEnoughResourcesException.getMessage(),"Not Enough Resources",JOptionPane.ERROR_MESSAGE );
				notEnoughResourcesException.printStackTrace();
			} catch (ChampionDisarmedException championDisarmedException) {
				JOptionPane.showMessageDialog(null,championDisarmedException.getMessage(),"Disarmed Champion",JOptionPane.ERROR_MESSAGE );
				championDisarmedException.printStackTrace();
			}
		});
		bottomframe.add(attackUp);

		JButton attackdown=new JButton("Attack Down");
		attackdown.addActionListener(e-> {
			try {
				g.attack(Direction.DOWN);
				UpdateForAttack(g,labels);
			}  catch (NotEnoughResourcesException notEnoughResourcesException) {
			JOptionPane.showMessageDialog(null,notEnoughResourcesException.getMessage(),"Not Enough Resources",JOptionPane.ERROR_MESSAGE );
			notEnoughResourcesException.printStackTrace();
			} catch (ChampionDisarmedException championDisarmedException) {
			JOptionPane.showMessageDialog(null,championDisarmedException.getMessage(),"Disarmed Champion",JOptionPane.ERROR_MESSAGE );
			championDisarmedException.printStackTrace();
			}
		});
		bottomframe.add(attackdown);

		JButton attackRight=new JButton("Attack Right");
		attackRight.addActionListener(e-> {
			try {
				g.attack(Direction.RIGHT);
				UpdateForAttack(g,labels);
			} catch (NotEnoughResourcesException notEnoughResourcesException) {
				JOptionPane.showMessageDialog(null,notEnoughResourcesException.getMessage(),"Not Enough Resources",JOptionPane.ERROR_MESSAGE );
				notEnoughResourcesException.printStackTrace();
			} catch (ChampionDisarmedException championDisarmedException) {
				JOptionPane.showMessageDialog(null,championDisarmedException.getMessage(),"Disarmed Champion",JOptionPane.ERROR_MESSAGE );
				championDisarmedException.printStackTrace();
			}
		});
		bottomframe.add(attackRight);

		JButton attackleft=new JButton("Attack Left");
		attackleft.addActionListener(e-> {
			try {
				g.attack(Direction.LEFT);
				UpdateForAttack(g,labels);
			} catch (NotEnoughResourcesException notEnoughResourcesException) {
				JOptionPane.showMessageDialog(null,notEnoughResourcesException.getMessage(),"Not Enough Resources",JOptionPane.ERROR_MESSAGE );
				notEnoughResourcesException.printStackTrace();
			} catch (ChampionDisarmedException championDisarmedException) {
				JOptionPane.showMessageDialog(null,championDisarmedException.getMessage(),"Disarmed Champion",JOptionPane.ERROR_MESSAGE );
				championDisarmedException.printStackTrace();
			}
		});
		bottomframe.add(attackleft);

		JButton useleader = new JButton("Leader ability");
		useleader.addActionListener(e-> {
			try {
				if(JOptionPane.showConfirmDialog(null,"Leader Ability can only be used ONCE","Are You Sure?" ,JOptionPane.YES_NO_OPTION)==0){
				g.useLeaderAbility();
					if (first.getTeam().contains(g.getCurrentChampion())){
						namefinfo.setText(" "+first.getName()+"\n"+"\n"+ " Leader: "+first.getLeader().getName()+"\n"+"\n"+
								" Leader Ability Used: "+ g.isFirstLeaderAbilityUsed()+ "\n"+"\n"+"Team Members:");
						for (Champion c: first.getTeam()){
							namefinfo.setText(namefinfo.getText()+ "\n"+ c.getName() );
						}
						namefinfo.setText( namefinfo.getText()+"\n"+ "\n"+
								"Current Champion: "+ g.getCurrentChampion().getName()+"\n"+
								" Type: "+g.getCurrentChampion().getClass().getSimpleName()+"\n"+
								" Current HP: "+ g.getCurrentChampion().getCurrentHP()+ "\n"+
								" Mana: "+ g.getCurrentChampion().getMana() + "\n"+
								" Current Action Points: "+ g.getCurrentChampion().getCurrentActionPoints());
					}
					if (second.getTeam().contains(g.getCurrentChampion())){
						names.setText(second.getName()+"\n"+"\n"+ "Leader: "+second.getLeader().getName()+"\n"+"\n"+
								"Leader Ability Used: "+ g.isSecondLeaderAbilityUsed()+ "\n"+"\n"+"Team Members:");
						for (Champion c: second.getTeam())
							names.setText(names.getText()+ "\n"+ c.getName() );

							names.setText(names.getText()+ "\n"+"\n"+
									"Current Champion: "+ g.getCurrentChampion().getName()+"\n"+
									" Type: "+g.getCurrentChampion().getClass().getSimpleName()+"\n"+
									" Current HP: "+ g.getCurrentChampion().getCurrentHP()+ "\n"+
									" Mana: "+ g.getCurrentChampion().getMana() + "\n"+
									" Current Action Points: "+ g.getCurrentChampion().getCurrentActionPoints());


					}
				UpdateForAttack(g,labels);
				useleader.setEnabled(false);
				System.out.print(g.getCurrentChampion().getCurrentActionPoints());}
			} catch (LeaderNotCurrentException leaderNotCurrentException) {
				JOptionPane.showMessageDialog(null,leaderNotCurrentException.getMessage(),"Current Champion is not Leader",JOptionPane.ERROR_MESSAGE );
				leaderNotCurrentException.printStackTrace();
			} catch (LeaderAbilityAlreadyUsedException leaderAbilityAlreadyUsedException) {
				JOptionPane.showMessageDialog(null,leaderAbilityAlreadyUsedException.getMessage(),"Leader Ability has been used already",JOptionPane.ERROR_MESSAGE );
				leaderAbilityAlreadyUsedException.printStackTrace();
			}
		});
		bottomframe.add(useleader);
		
		JButton castability1 = new JButton(g.getCurrentChampion().getAbilities().get(0).getName());
		JButton castability2= new JButton(g.getCurrentChampion().getAbilities().get(1).getName());
		JButton castability3= new JButton(g.getCurrentChampion().getAbilities().get(2).getName());

		castability1.addActionListener(e->{
			try {
				Ads(castability1,g.getCurrentChampion().getAbilities().get(0),g,labels);
			} catch (NotEnoughResourcesException notEnoughResourcesException) {
				notEnoughResourcesException.printStackTrace();
			} catch (AbilityUseException abilityUseException) {
				abilityUseException.printStackTrace();
			}
		});
		castability2.addActionListener(e->{
			try {
				Ads(castability2,g.getCurrentChampion().getAbilities().get(1),g,labels);
			} catch (NotEnoughResourcesException notEnoughResourcesException) {
				notEnoughResourcesException.printStackTrace();
			} catch (AbilityUseException abilityUseException) {
				abilityUseException.printStackTrace();
			}

		});
		castability3.addActionListener(e->{
			try {
				Ads(castability3,g.getCurrentChampion().getAbilities().get(2),g,labels);
			} catch (NotEnoughResourcesException notEnoughResourcesException) {
				notEnoughResourcesException.printStackTrace();
			} catch (AbilityUseException abilityUseException) {
				abilityUseException.printStackTrace();
			}
		});
		bottomframe.add(castability1);
		bottomframe.add(castability2);
		bottomframe.add(castability3);

		ImageIcon img=new ImageIcon("Cover.png");

		JButton endturn = new JButton("End Turn");
		endturn.addActionListener(e-> {
			if (g.getCurrentChampion().isDisarmed())
				bottomframe.remove(castability4);

			g.endTurn();
			for(int i=0;i<5;i++)
				for(int j=0;j<5;j++) {
					if(g.getBoard()[i][j]!=null && g.getBoard()[i][j] instanceof Cover) {
						labels.get((((4-i)*5+j))).setText(" HP "+((Cover)g.getBoard()[i][j]).getCurrentHP());
						labels.get((((4-i)*5+j))).setIcon(img);
						labels.get((((4-i)*5+j))).setVerticalTextPosition(SwingConstants.BOTTOM);
						labels.get((((4-i)*5+j))).setHorizontalTextPosition(SwingConstants.CENTER);
					}
					if(g.getBoard()[i][j]!=null && g.getBoard()[i][j] instanceof Champion) {
						labels.get((((4-i)*5+j))).setText("<html>"+((Champion)g.getBoard()[i][j]).getName()+"<br> HP:"+((Champion)g.getBoard()[i][j]).getCurrentHP());
						labels.get((((4-i)*5+j))).setForeground(Color.black);
						boolean leader= g.getBoard()[i][j].equals(g.getFirstPlayer().getLeader()) ||
								g.getBoard()[i][j].equals(g.getSecondPlayer().getLeader());

						labels.get((((4-i)*5+j))).setToolTipText("<html> Type: "+ g.getBoard()[i][j].getClass().getSimpleName()+
								"<br> Mana: "+ ((Champion) g.getBoard()[i][j]).getMana()+
								"<br> CurrentHP: "+ ((Champion) g.getBoard()[i][j]).getCurrentHP()+
								"<br> Speed: "+ ((Champion) g.getBoard()[i][j]).getSpeed()+
								"<br> Max Action Points Per Turn: "+ ((Champion) g.getBoard()[i][j]).getMaxActionPointsPerTurn()+
								"<br> Attack Damage: "+ ((Champion) g.getBoard()[i][j]).getAttackDamage()+
								"<br> Attack Range: "+ ((Champion) g.getBoard()[i][j]).getAttackRange()+
								"<br> Leader: "+  leader+
								"<br> Applied Effects: ");
						if (((Champion) g.getBoard()[i][j]).getAppliedEffects().size()>0)
							for (Effect ef: ((Champion) g.getBoard()[i][j]).getAppliedEffects())
								labels.get((((4-i)*5+j))).setToolTipText(labels.get((((4-i)*5+j))).getToolTipText()+ "<br> "+ ef.getName()+", Duration:"+ef.getDuration()+" Turns");

						if (g.getBoard()[i][j].equals(g.getCurrentChampion())){
							labels.get((((4-i)*5+j))).setForeground(Color.RED);
						}
					}
				}
			if (second.getTeam().contains(g.getCurrentChampion())){
				names.setText(second.getName()+"\n"+"\n"+ "Leader: "+second.getLeader().getName()+"\n"+"\n"+
						"Leader Ability Used: "+ g.isSecondLeaderAbilityUsed()+ "\n"+"\n"+"Team Members:");

				for (Champion c: second.getTeam())
					names.setText(names.getText()+ "\n"+ c.getName() );

				names.setText(names.getText()+ "\n"+"\n"+
						"Current Champion: "+ g.getCurrentChampion().getName()+"\n"+
						" Type: "+g.getCurrentChampion().getClass().getSimpleName()+"\n"+
						" Current HP: "+ g.getCurrentChampion().getCurrentHP()+ "\n"+
						" Mana: "+ g.getCurrentChampion().getMana() + "\n"+
						" Current Action Points: "+ g.getCurrentChampion().getCurrentActionPoints()+"\n"+"\n"+
						" Abilities:");
					if (!g.getCurrentChampion().isDisarmed()){
						for (Ability a : g.getCurrentChampion().getAbilities()) {
							if (a instanceof DamagingAbility)
								names.setText(names.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
										+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
										"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
										"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
										"  Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+"\n");
							else if (a instanceof HealingAbility)
								names.setText(names.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
										+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
										"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
										"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
										"  Healing Amount: " + ((HealingAbility) a).getHealAmount()+"\n");
							else if (a instanceof CrowdControlAbility)
								names.setText(names.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
										+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
										"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
										"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
										"  Effect: " + ((CrowdControlAbility) a).getEffect().getName()+"\n");


						}

					}
					else{
						Ability a= g.getCurrentChampion().getAbilities().get(3);
						names.setText(names.getText()+"\n"+a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+"\n");
					}
				namefinfo.setText(" "+first.getName()+"\n"+"\n"+ " Leader: "+first.getLeader().getName()+"\n"+"\n"+
						" Leader Ability Used: "+ g.isFirstLeaderAbilityUsed()+ "\n"+"\n"+"Team Members:");
				for (Champion c: first.getTeam()){
					namefinfo.setText(namefinfo.getText()+ "\n"+ c.getName() );
				}
			}
			if (first.getTeam().contains(g.getCurrentChampion())){
				namefinfo.setText(" "+first.getName()+"\n"+"\n"+ " Leader: "+first.getLeader().getName()+"\n"+"\n"+
						" Leader Ability Used: "+ g.isFirstLeaderAbilityUsed() + "\n"+"\n"+"Team Members:");
				for (Champion c: first.getTeam()){
					namefinfo.setText(namefinfo.getText()+ "\n"+ c.getName() );
				}
					namefinfo.setText(namefinfo.getText()+ "\n"+"\n"+
							"Current Champion: "+ g.getCurrentChampion().getName()+"\n"+
							" Type: "+g.getCurrentChampion().getClass().getSimpleName()+"\n"+
							" Current HP: "+ g.getCurrentChampion().getCurrentHP()+ "\n"+
							" Mana: "+ g.getCurrentChampion().getMana() + "\n"+
							" Current Action Points: "+ g.getCurrentChampion().getCurrentActionPoints()+ "\n" + "\n" +
							" Abilities:");
				if (!g.getCurrentChampion().isDisarmed()){
					for (Ability a : g.getCurrentChampion().getAbilities()) {
					if (a instanceof DamagingAbility)
						namefinfo.setText(namefinfo.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+"\n");
					else if (a instanceof HealingAbility)
						namefinfo.setText(namefinfo.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Healing Amount: " + ((HealingAbility) a).getHealAmount()+"\n");
					else if (a instanceof CrowdControlAbility)
						namefinfo.setText(namefinfo.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Effect: " + ((CrowdControlAbility) a).getEffect().getName()+"\n");
				}
				}
				else{
					Ability a= g.getCurrentChampion().getAbilities().get(3);
					namefinfo.setText(namefinfo.getText()+"\n"+a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
							+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
							"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
							"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
							"  Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+"\n");
				}
				names.setText(" "+second.getName()+"\n"+"\n"+ " Leader: "+second.getLeader().getName()+"\n"+"\n"+
						" Leader Ability Used: "+ g.isSecondLeaderAbilityUsed()+ "\n"+"\n"+"Team Members:");
				for (Champion c: second.getTeam())
					names.setText(names.getText()+ "\n"+ c.getName() );
			}
			castability1.setText(g.getCurrentChampion().getAbilities().get(0).getName());
			castability2.setText(g.getCurrentChampion().getAbilities().get(1).getName());
			castability3.setText(g.getCurrentChampion().getAbilities().get(2).getName());

			if (g.getCurrentChampion().getAbilities().size()>3) {
				castability4= new JButton(g.getCurrentChampion().getAbilities().get(3).getName());
				JButton finalCastability = castability4;
				castability4.addActionListener(event->{
					try {
						Ads(finalCastability,g.getCurrentChampion().getAbilities().get(3),g, labels);
					} catch (NotEnoughResourcesException notEnoughResourcesException) {
						notEnoughResourcesException.printStackTrace();
					} catch (AbilityUseException abilityUseException) {
						abilityUseException.printStackTrace();
					}
				});
				bottomframe.add(finalCastability);
			}

		});

		//Ads(castability4,g.getCurrentChampion().getAbilities().get(3),g, labels);

		/*if (g.getCurrentChampion().getAbilities().get(0).getCastArea()==AreaOfEffect.DIRECTIONAL) {

			JFrame x = new JFrame();
			x.setLayout(new GridLayout(2,2));
			x.add(new JButton("Up"));
			x.add(new JButton("Down"));
			x.add(new JButton("Right"));
			x.add(new JButton("Left"));
			castability1.addActionListener(e->x.setVisible(true));

		}*/
		bottomframe.add(endturn);

		for(int i=0;i<5;i++)
			for(int j=0;j<5;j++) {
				if(g.getBoard()[i][j]!=null && g.getBoard()[i][j] instanceof Cover) {
					labels.get((((4-i)*5+j))).setText(" HP "+((Cover)g.getBoard()[i][j]).getCurrentHP());
					labels.get((((4-i)*5+j))).setIcon(img);
					labels.get((((4-i)*5+j))).setVerticalTextPosition(SwingConstants.BOTTOM);
					labels.get((((4-i)*5+j))).setHorizontalTextPosition(SwingConstants.CENTER);
				}
				if(g.getBoard()[i][j]!=null && g.getBoard()[i][j] instanceof Champion) {
					labels.get((((4-i)*5+j))).setText("<html>"+((Champion)g.getBoard()[i][j]).getName()+"<br> HP:"+((Champion)g.getBoard()[i][j]).getCurrentHP());
					labels.get((((4-i)*5+j))).setForeground(Color.black);
					boolean leader= ((Champion) g.getBoard()[i][j]).equals(first.getLeader()) || ((Champion) g.getBoard()[i][j]).equals(second.getLeader());
					labels.get((((4-i)*5+j))).setToolTipText("<html> Type: "+ g.getBoard()[i][j].getClass().getSimpleName()+
							"<br> Mana: "+ ((Champion) g.getBoard()[i][j]).getMana()+
							"<br> CurrentHP: "+ ((Champion) g.getBoard()[i][j]).getCurrentHP()+
							"<br> Speed: "+ ((Champion) g.getBoard()[i][j]).getSpeed()+
							"<br> Max Action Points Per Turn: "+ ((Champion) g.getBoard()[i][j]).getMaxActionPointsPerTurn()+
							"<br> Attack Damage: "+ ((Champion) g.getBoard()[i][j]).getAttackDamage()+
							"<br> Attack Range: "+ ((Champion) g.getBoard()[i][j]).getAttackRange()+
							"<br> Leader: "+  leader+
							"<br> Applied Effects: ");
					if (((Champion) g.getBoard()[i][j]).getAppliedEffects().size()>0)
						for (Effect e: ((Champion) g.getBoard()[i][j]).getAppliedEffects())
							labels.get((((4-i)*5+j))).setToolTipText(labels.get((((4-i)*5+j))).getToolTipText()+ "<br> "+ e.getName()+", Duration:"+e.getDuration()+" Turns");

					if (g.getBoard()[i][j].equals(g.getCurrentChampion())){
						labels.get((((4-i)*5+j))).setForeground(Color.RED);
					}
					
				}
			}

		mainPanel.add(bottomframe,BorderLayout.SOUTH);
		this.revalidate();
		this.repaint();
	}
	public void PlaceOnChampGrid(Game g,ArrayList<JButton> labels,Point p) {
		if (g.checkGameOver()!=null){
			winner(g);
			return;
		}
		labels.get((((4-p.x)*5+p.y))).setText(null);
		labels.get((((4-p.x)*5+p.y))).setToolTipText(null);
		for(int i=0;i<5;i++) {
			for(int j=0;j<5;j++) {
				if(g.getBoard()[i][j]!=null && g.getBoard()[i][j] instanceof Champion) {
					labels.get((((4-i)*5+j))).setText("<html>"+((Champion)g.getBoard()[i][j]).getName()+"<br> HP:"+((Champion)g.getBoard()[i][j]).getCurrentHP());
					labels.get((((4-i)*5+j))).setForeground(Color.black);
					boolean leader= ((Champion) g.getBoard()[i][j]).equals(g.getFirstPlayer().getLeader()) ||
							((Champion) g.getBoard()[i][j]).equals(g.getSecondPlayer().getLeader());
					labels.get((((4-i)*5+j))).setToolTipText("<html> Type: "+ g.getBoard()[i][j].getClass().getSimpleName()+
							"<br> Mana: "+ ((Champion) g.getBoard()[i][j]).getMana()+
							"<br> CurrentHP: "+ ((Champion) g.getBoard()[i][j]).getCurrentHP()+
							"<br> Speed: "+ ((Champion) g.getBoard()[i][j]).getSpeed()+
							"<br> Max Action Points Per Turn: "+ ((Champion) g.getBoard()[i][j]).getMaxActionPointsPerTurn()+
							"<br> Attack Damage: "+ ((Champion) g.getBoard()[i][j]).getAttackDamage()+
							"<br> Attack Range: "+ ((Champion) g.getBoard()[i][j]).getAttackRange()+
							"<br> Leader: "+  leader+
							"<br> Applied Effects: ");
					if (((Champion) g.getBoard()[i][j]).getAppliedEffects().size()>0)
						for (Effect e: ((Champion) g.getBoard()[i][j]).getAppliedEffects())
							labels.get((((4-i)*5+j))).setToolTipText(labels.get((((4-i)*5+j))).getToolTipText()+ "<br> "+ e.getName()+", Duration:"+e.getDuration()+" Turns");

					if (g.getBoard()[i][j].equals(g.getCurrentChampion())){
						labels.get((((4-i)*5+j))).setForeground(Color.RED);
					}
				}
			}
		}
		if (g.getFirstPlayer().getTeam().contains(g.getCurrentChampion())){
			namefinfo.setText(" "+g.getFirstPlayer().getName()+"\n"+"\n"+ " Leader: "+g.getFirstPlayer().getLeader().getName()+"\n"+"\n"+
					" Leader Ability Used: "+ g.isFirstLeaderAbilityUsed() + "\n"+"\n"+"Team Members:");
			for (Champion c: g.getFirstPlayer().getTeam()){
				namefinfo.setText(namefinfo.getText()+ "\n"+ c.getName() );
			}
				namefinfo.setText(namefinfo.getText() + "\n" + "\n" +
						"Current Champion: " + g.getCurrentChampion().getName() + "\n" +
						" Type: " + g.getCurrentChampion().getClass().getSimpleName() + "\n" +
						" Current HP: " + g.getCurrentChampion().getCurrentHP() + "\n" +
						" Mana: " + g.getCurrentChampion().getMana() + "\n" +
						" Current Action Points: " + g.getCurrentChampion().getCurrentActionPoints() + "\n" + "\n" +
						" Abilities:");

			if (!g.getCurrentChampion().isDisarmed()) {
				for (Ability a : g.getCurrentChampion().getAbilities()) {
					if (a instanceof DamagingAbility)
						namefinfo.setText(namefinfo.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Damage Amount: " + ((DamagingAbility) a).getDamageAmount() + "\n");
					else if (a instanceof HealingAbility)
						namefinfo.setText(namefinfo.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Healing Amount: " + ((HealingAbility) a).getHealAmount() + "\n");
					else if (a instanceof CrowdControlAbility)
						namefinfo.setText(namefinfo.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Effect: " + ((CrowdControlAbility) a).getEffect().getName() + "\n");
				}

			}
			else{
				Ability a= g.getCurrentChampion().getAbilities().get(3);
				namefinfo.setText(namefinfo.getText()+"\n"+a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
						+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
						"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
						"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
						"  Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+"\n");
			}
				/*if (g.getCurrentChampion().getAppliedEffects().size()>0){
					namefinfo.setText(namefinfo.getText()+"\n"+" Applied Effects: ");
					for (Effect e:g.getCurrentChampion().getAppliedEffects()){
						namefinfo.setText(namefinfo.getText()+"\n"+"  "+e.getName()+", Duration: "+e.getDuration());
					}
				}*/
		}
		if (g.getSecondPlayer().getTeam().contains(g.getCurrentChampion())){
			names.setText(g.getSecondPlayer().getName()+"\n"+"\n"+ "Leader: "+g.getSecondPlayer().getLeader().getName()+"\n"+"\n"+
				"Leader Ability Used: "+ g.isSecondLeaderAbilityUsed()+ "\n"+"\n"+"Team Members:");

			for (Champion c: g.getSecondPlayer().getTeam())
				names.setText(names.getText()+ "\n"+ c.getName() );

				names.setText(names.getText()+ "\n"+"\n"+
						"Current Champion: "+ g.getCurrentChampion().getName()+"\n"+
						" Type: "+g.getCurrentChampion().getClass().getSimpleName()+"\n"+
						" Current HP: "+ g.getCurrentChampion().getCurrentHP()+ "\n"+
						" Mana: "+ g.getCurrentChampion().getMana() + "\n"+
						" Current Action Points: "+ g.getCurrentChampion().getCurrentActionPoints()+"\n"+"\n"+
						" Abilities:");
			if (!g.getCurrentChampion().isDisarmed())
				for (Ability a : g.getCurrentChampion().getAbilities()) {
					if (a instanceof DamagingAbility)
						names.setText(names.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+"\n");
					else if (a instanceof HealingAbility)
						names.setText(names.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Healing Amount: " + ((HealingAbility) a).getHealAmount()+"\n");
					else if (a instanceof CrowdControlAbility)
						names.setText(names.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Effect: " + ((CrowdControlAbility) a).getEffect().getName()+"\n");
				}
			else{
				Ability a= g.getCurrentChampion().getAbilities().get(3);
				names.setText(names.getText()+"\n"+a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
						+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
						"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
						"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
						"  Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+"\n");
			}
				/*if (g.getCurrentChampion().getAppliedEffects().size()>0){
					names.setText(names.getText()+"\n"+" Applied Effects: ");
					for (Effect e:g.getCurrentChampion().getAppliedEffects()){
						names.setText(names.getText()+"\n"+"  "+e.getName()+", Duration: "+e.getDuration());
					}
				}*/
			}
		}

	public void UpdateForAttack(Game g,ArrayList<JButton> labels) {
		if (g.checkGameOver()!=null){
			winner(g);
			return;
		}
		for(int i=0;i<5;i++)
			for(int j=0;j<5;j++) {
				if(g.getBoard()[i][j]==null && labels.get((((4-i)*5+j))).getText()!=null){
					labels.get((((4-i)*5+j))).setText(null);
					labels.get((((4-i)*5+j))).setIcon(null);
					labels.get((((4-i)*5+j))).setToolTipText(null);
				}
				if(g.getBoard()[i][j]!=null && g.getBoard()[i][j] instanceof Cover) {
					if(((Cover)g.getBoard()[i][j]).getCurrentHP()>0) {
						labels.get((((4-i)*5+j))).setText("HP "+((Cover)g.getBoard()[i][j]).getCurrentHP());
						labels.get((((4-i)*5+j))).setVerticalTextPosition(SwingConstants.BOTTOM);
						labels.get((((4-i)*5+j))).setHorizontalTextPosition(SwingConstants.CENTER);
					}
					
				}
				if(g.getBoard()[i][j]!=null && g.getBoard()[i][j] instanceof Champion) {
					labels.get((((4-i)*5+j))).setText("<html>"+((Champion)g.getBoard()[i][j]).getName()+"<br> HP:"+((Champion)g.getBoard()[i][j]).getCurrentHP());
					labels.get((((4-i)*5+j))).setForeground(Color.black);
					boolean leader= g.getBoard()[i][j].equals(g.getFirstPlayer().getLeader()) ||
							g.getBoard()[i][j].equals(g.getSecondPlayer().getLeader());

					labels.get((((4-i)*5+j))).setToolTipText("<html> Type: "+ g.getBoard()[i][j].getClass().getSimpleName()+
							"<br> Mana: "+ ((Champion) g.getBoard()[i][j]).getMana()+
							"<br> CurrentHP: "+ ((Champion) g.getBoard()[i][j]).getCurrentHP()+
							"<br> Speed: "+ ((Champion) g.getBoard()[i][j]).getSpeed()+
							"<br> Max Action Points Per Turn: "+ ((Champion) g.getBoard()[i][j]).getMaxActionPointsPerTurn()+
							"<br> Attack Damage: "+ ((Champion) g.getBoard()[i][j]).getAttackDamage()+
							"<br> Attack Range: "+ ((Champion) g.getBoard()[i][j]).getAttackRange()+
							"<br> Leader: "+  leader+
							"<br> Applied Effects: ");
					if (((Champion) g.getBoard()[i][j]).getAppliedEffects().size()>0)
						for (Effect e: ((Champion) g.getBoard()[i][j]).getAppliedEffects())
							labels.get((((4-i)*5+j))).setToolTipText(labels.get((((4-i)*5+j))).getToolTipText()+ "<br> "+ e.getName()+", Duration:"+e.getDuration()+" Turns");

					if (g.getBoard()[i][j].equals(g.getCurrentChampion())){
						labels.get((((4-i)*5+j))).setForeground(Color.RED);
					}

				}
			}
		if (g.getSecondPlayer().getTeam().contains(g.getCurrentChampion())){
			names.setText(g.getSecondPlayer().getName()+"\n"+"\n"+ "Leader: "+g.getSecondPlayer().getLeader().getName()+"\n"+"\n"+
					"Leader Ability Used: "+ g.isSecondLeaderAbilityUsed()+ "\n"+"\n"+"Team Members:");

			for (Champion c: g.getSecondPlayer().getTeam())
				names.setText(names.getText()+ "\n"+ c.getName() );

			names.setText(names.getText()+ "\n"+"\n"+
					"Current Champion: "+ g.getCurrentChampion().getName()+"\n"+
					" Type: "+g.getCurrentChampion().getClass().getSimpleName()+"\n"+
					" Current HP: "+ g.getCurrentChampion().getCurrentHP()+ "\n"+
					" Mana: "+ g.getCurrentChampion().getMana() + "\n"+
					" Current Action Points: "+ g.getCurrentChampion().getCurrentActionPoints()+"\n"+"\n"+
					" Abilities:");
			if (!g.getCurrentChampion().isDisarmed())
				for (Ability a : g.getCurrentChampion().getAbilities()) {
					if (a instanceof DamagingAbility)
						names.setText(names.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+"\n");
					else if (a instanceof HealingAbility)
						names.setText(names.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Healing Amount: " + ((HealingAbility) a).getHealAmount()+"\n");
					else if (a instanceof CrowdControlAbility)
						names.setText(names.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Effect: " + ((CrowdControlAbility) a).getEffect().getName()+"\n");
				}
			else{
				Ability a= g.getCurrentChampion().getAbilities().get(3);
				names.setText(names.getText()+"\n"+a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
						+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
						"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
						"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
						"  Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+"\n");
			}
			namefinfo.setText(" "+g.getFirstPlayer().getName()+"\n"+"\n"+ " Leader: "+g.getFirstPlayer().getLeader().getName()+"\n"+"\n"+
					" Leader Ability Used: "+ g.isFirstLeaderAbilityUsed()+ "\n"+"\n"+"Team Members:");
			for (Champion c: g.getFirstPlayer().getTeam()){
				namefinfo.setText(namefinfo.getText()+ "\n"+ c.getName() );
			}
		}
		if (g.getFirstPlayer().getTeam().contains(g.getCurrentChampion())){
			namefinfo.setText(" "+g.getFirstPlayer().getName()+"\n"+"\n"+ " Leader: "+g.getFirstPlayer().getLeader().getName()+"\n"+"\n"+
					" Leader Ability Used: "+ g.isFirstLeaderAbilityUsed() + "\n"+"\n"+"Team Members:");
			for (Champion c: g.getFirstPlayer().getTeam()){
				namefinfo.setText(namefinfo.getText()+ "\n"+ c.getName() );
			}
			namefinfo.setText(namefinfo.getText()+ "\n"+"\n"+
					"Current Champion: "+ g.getCurrentChampion().getName()+"\n"+
					" Type: "+g.getCurrentChampion().getClass().getSimpleName()+"\n"+
					" Current HP: "+ g.getCurrentChampion().getCurrentHP()+ "\n"+
					" Mana: "+ g.getCurrentChampion().getMana() + "\n"+
					" Current Action Points: "+ g.getCurrentChampion().getCurrentActionPoints()+ "\n" + "\n" +
					" Abilities:");
			if (!g.getCurrentChampion().isDisarmed())
				for (Ability a : g.getCurrentChampion().getAbilities()) {
					if (a instanceof DamagingAbility)
						namefinfo.setText(namefinfo.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+"\n");
					else if (a instanceof HealingAbility)
						namefinfo.setText(namefinfo.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Healing Amount: " + ((HealingAbility) a).getHealAmount()+"\n");
					else if (a instanceof CrowdControlAbility)
						namefinfo.setText(namefinfo.getText() + "\n" + a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
								+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
								"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
								"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
								"  Effect: " + ((CrowdControlAbility) a).getEffect().getName()+"\n");
				}
			else{
				Ability a= g.getCurrentChampion().getAbilities().get(3);
				namefinfo.setText(namefinfo.getText()+"\n"+a.getName() + "\n" + "  Type: " + a.getClass().getSimpleName() + "\n"
						+ "  Area of Effect: " + a.getCastArea().name() + "\n" + "  Cast Range: " + a.getCastRange() + " cells" + "\n" +
						"  Mana Cost: " + a.getManaCost() + "\n" + "  Required Action Points: " + a.getRequiredActionPoints() + "\n" +
						"  Base Cooldown: " + a.getBaseCooldown() + "\n" + "  Current Cooldown: " + a.getCurrentCooldown() + "\n" +
						"  Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+"\n");
			}
			names.setText(" "+g.getSecondPlayer().getName()+"\n"+"\n"+ " Leader: "+g.getSecondPlayer().getLeader().getName()+"\n"+"\n"+
					" Leader Ability Used: "+ g.isSecondLeaderAbilityUsed()+ "\n"+"\n"+"Team Members:");
			for (Champion c: g.getSecondPlayer().getTeam())
				names.setText(names.getText()+ "\n"+ c.getName() );
		}
		return;
	}
	
	
	public void showabilities(Game g,JPanel left,JPanel right) {
		String abilitiess[] = {g.getCurrentChampion().getAbilities().get(0).getName(),g.getCurrentChampion().getAbilities().get(1).getName(),g.getCurrentChampion().getAbilities().get(2).getName()};
		JComboBox cal = new JComboBox(abilitiess);
    	left.add(cal,BorderLayout.NORTH);
		JComboBox car = new JComboBox(abilitiess);
		right.add(car,BorderLayout.NORTH);
	}
	public void Ads (JButton x, Ability a ,Game game,ArrayList<JButton> labels) throws NotEnoughResourcesException, AbilityUseException {
		if(a.getCastArea()==AreaOfEffect.DIRECTIONAL) {
			JFrame y = new JFrame();
			y.setLayout(new GridLayout(2,2));
			y.setSize(100,100);
			y.setVisible(true);
			//x.add(new JButton("Up"));
		//	x.add(new JButton("Down"));
		//	x.add(new JButton("Right"));
		//	x.add(new JButton("Left"));
			//castability1.addActionListener(e->x.setVisible(true));
			//JLabel label = new JLabel();
			//label.setVisible(false);
			//label.setBounds(500,500,80,80);
			//x.addActionListener(e->label.setVisible(true));
		//	Form (y,a ,game);
			JButton button1 = new JButton("Up");
			JButton button2 = new JButton("Down");
			JButton button3 = new JButton("Right");
			JButton button4 = new JButton("left");
			button1.addActionListener(e ->{
				try{
					game.castAbility(a, Direction.UP);
					UpdateForAttack(game, labels);
					y.dispose();
					return;
				}
				catch (NotEnoughResourcesException notEnoughResourcesException) {
					JOptionPane.showMessageDialog(null,notEnoughResourcesException.getMessage(),"There is not enough resources",JOptionPane.ERROR_MESSAGE );
					notEnoughResourcesException.printStackTrace();
				}
				catch (AbilityUseException abilityUseException) {
					JOptionPane.showMessageDialog(null,abilityUseException.getMessage(),"You cannot use the ability",JOptionPane.ERROR_MESSAGE );
					abilityUseException.printStackTrace();

				} catch (CloneNotSupportedException e1) {
					e1.printStackTrace();
				}
			});
			button1.setBounds(200,200,50,50);
			button2.addActionListener(e->{
				try{
					game.castAbility(a, Direction.DOWN);
					UpdateForAttack(game, labels);
					y.dispose();
					return;
				}
				catch (NotEnoughResourcesException notEnoughResourcesException) {
					JOptionPane.showMessageDialog(null,notEnoughResourcesException.getMessage(),"There is not enough resources",JOptionPane.ERROR_MESSAGE );
					notEnoughResourcesException.printStackTrace();
				}
				catch (AbilityUseException abilityUseException) {
					JOptionPane.showMessageDialog(null,abilityUseException.getMessage(),"You cannot use the ability",JOptionPane.ERROR_MESSAGE );
					abilityUseException.printStackTrace();

				} catch (CloneNotSupportedException e1) {
					e1.printStackTrace();
				}
			});
			button2.setBounds(200,100,50,50);
			button3.addActionListener(e->{
				try{
					game.castAbility(a, Direction.RIGHT);
					UpdateForAttack(game, labels);
					y.dispose();
					return;
				}
				catch (NotEnoughResourcesException notEnoughResourcesException) {
					JOptionPane.showMessageDialog(null,notEnoughResourcesException.getMessage(),"There is not enough resources",JOptionPane.ERROR_MESSAGE );
					notEnoughResourcesException.printStackTrace();
				}
				catch (AbilityUseException abilityUseException) {
					JOptionPane.showMessageDialog(null,abilityUseException.getMessage(),"You cannot use the ability",JOptionPane.ERROR_MESSAGE );
					abilityUseException.printStackTrace();

				} catch (CloneNotSupportedException e1) {
					e1.printStackTrace();
				}
			});
			button3.setBounds(300,200,50,50);
			button4.addActionListener(e->{
				try{
					game.castAbility(a, Direction.LEFT);
					UpdateForAttack(game, labels);
					y.dispose();
					return;
				}
				catch (NotEnoughResourcesException notEnoughResourcesException) {
					JOptionPane.showMessageDialog(null,notEnoughResourcesException.getMessage(),"There is not enough resources",JOptionPane.ERROR_MESSAGE );
					notEnoughResourcesException.printStackTrace();
				}
				catch (AbilityUseException abilityUseException) {
					JOptionPane.showMessageDialog(null,abilityUseException.getMessage(),"You cannot use the ability",JOptionPane.ERROR_MESSAGE );
					abilityUseException.printStackTrace();

				} catch (CloneNotSupportedException e1) {
					e1.printStackTrace();
				}
			});
			button4.setBounds(300,300,50,50);
			y.add(button1);
			y.add(button2);
			y.add(button3);
			y.add(button4);
			//x.setVisible(false);
			if (game.checkGameOver()!=null){
				winner(game);
				return;
			}

		}
		else if (a.getCastArea()==AreaOfEffect.TEAMTARGET||a.getCastArea()==AreaOfEffect.SURROUND||a.getCastArea()==AreaOfEffect.SELFTARGET) {
				try {
					game.castAbility(a);
					UpdateForAttack(game, labels);
					return;
				}
				catch (NotEnoughResourcesException notEnoughResourcesException) {
					JOptionPane.showMessageDialog(null,notEnoughResourcesException.getMessage(),"There is not enough resources",JOptionPane.ERROR_MESSAGE );
                     notEnoughResourcesException.printStackTrace();	 
	         }
	         catch (AbilityUseException abilityUseException) {
					JOptionPane.showMessageDialog(null,abilityUseException.getMessage(),"You cannot use the ability",JOptionPane.ERROR_MESSAGE );
					abilityUseException.printStackTrace();	 

	          } catch (CloneNotSupportedException e1) {
				e1.printStackTrace();
			}
			if (game.checkGameOver()!=null){
				winner(game);
				return;
			}
	}
		else if (a.getCastArea()==AreaOfEffect.SINGLETARGET) {
			JOptionPane.showMessageDialog(null,"Please Select a cell to cast ability","Choose Single Target",JOptionPane.INFORMATION_MESSAGE);
			Add(labels, game, a);
			for(int i =0;i<5;i++) {
				for(int j=0;j<5;j++) {
					labels.get((((4-i)*5+j))).addActionListener(null);
				}
			}
			return;
		}
		if (game.checkGameOver()!=null){
			winner(game);
			return;
		}
		//UpdateForAttack(game, labels);
	}
	public void Add (ArrayList<JButton> x,Game game , Ability a ) {
		for(int i =0;i<5;i++) {
			for (int j =0;j<5;j++) {
				int finalI = i;
				int finalJ = j;
				x.get((((4-i)*5+j))).addActionListener(e->{
					try{
						game.castAbility(a, finalI, finalJ);
						UpdateForAttack(game, x);
					}catch (NotEnoughResourcesException notEnoughResourcesException) {
						JOptionPane.showMessageDialog(null,notEnoughResourcesException.getMessage(),"There is not enough resources",JOptionPane.ERROR_MESSAGE );
						notEnoughResourcesException.printStackTrace();
						return;
					}
					catch (AbilityUseException abilityUseException) {
						JOptionPane.showMessageDialog(null,abilityUseException.getMessage(),"You cannot use the ability",JOptionPane.ERROR_MESSAGE );
						abilityUseException.printStackTrace();
						return;

					} catch (CloneNotSupportedException e1) {
						e1.printStackTrace();
					}  catch (InvalidTargetException InvalidTargetException) {
						JOptionPane.showMessageDialog(null,InvalidTargetException.getMessage(),"Invalid target",JOptionPane.ERROR_MESSAGE );
						InvalidTargetException.printStackTrace();
						return;

					}
				});
			}
		}
		if (game.checkGameOver()!=null){
			winner(game);
			return;
		}
	}
	public void winner(Game g){
		mainPanel.removeAll();
		background.removeAll();
		background.setIcon(new ImageIcon("Winner.png"));
		JTextArea win=new JTextArea(g.checkGameOver().getName()+"! YOU WON");
		win.setBounds(200,100,1000,200);
		win.setFont(new Font(Font.MONOSPACED,Font.BOLD,30));
		background.add(win);
		mainPanel.add(background);
	}
	public static void main(String []args) {
		new Play();
	}

	}
